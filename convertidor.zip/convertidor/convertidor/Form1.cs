namespace convertidor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Evento Load - Se ejecuta cuando el formulario se carga
        private void Form1_Load(object sender, EventArgs e)
        {
            // Configurar el ComboBox con las opciones
            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(new object[] {
                "km a millas",
                "millas a km",
                "C a F",
                "F a C"
            });

            // Seleccionar el primer elemento por defecto
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }

            // Enfocar el TextBox para que el usuario pueda escribir
            textBox1.Focus();

            // Mostrar mensaje inicial
            label3.Text = "RESULTADO :";
        }

        // Bot�n CONVERTIR
        private void button1_Click(object sender, EventArgs e)
        {
            // VALIDACI�N 1: �El usuario ingres� un valor?
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Por favor, ingrese un valor para convertir.",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            // VALIDACI�N 2: �El usuario seleccion� un tipo de conversi�n?
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un tipo de conversi�n.",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
                comboBox1.Focus();
                return;
            }

            try
            {
                // Obtener el valor a convertir
                double valor = double.Parse(textBox1.Text);
                double resultado = 0;
                string unidadOrigen = "";
                string unidadDestino = "";

                // Realizar la conversi�n seg�n la selecci�n del ComboBox
                switch (comboBox1.SelectedItem.ToString())
                {
                    case "km a millas":
                        resultado = valor * 0.621371;
                        unidadOrigen = "km";
                        unidadDestino = "millas";
                        break;

                    case "millas a km":
                        resultado = valor * 1.60934;
                        unidadOrigen = "millas";
                        unidadDestino = "km";
                        break;

                    case "C a F":
                        resultado = (valor * 9 / 5) + 32;
                        unidadOrigen = "�C";
                        unidadDestino = "�F";
                        break;

                    case "F a C":
                        resultado = (valor - 32) * 5 / 9;
                        unidadOrigen = "�F";
                        unidadDestino = "�C";
                        break;

                    default:
                        MessageBox.Show("Tipo de conversi�n no soportado.",
                                      "Error",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                        return;
                }

                // Mostrar el resultado en label3 con 2 decimales
                label3.Text = $"RESULTADO: {valor} {unidadOrigen} = {resultado:F2} {unidadDestino}";
                label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un valor num�rico v�lido (use punto para decimales).",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
                textBox1.Clear();
                textBox1.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurri� un error: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        // Bot�n LIMPIAR
        private void button2_Click(object sender, EventArgs e)
        {
            // Limpiar todos los campos
            textBox1.Clear();                    // Vac�a el TextBox
            comboBox1.SelectedIndex = -1;        // Deselecciona el ComboBox
            label3.Text = "RESULTADO :";         // Restablece el Label

            // Volver a seleccionar el primer elemento
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }

            // Enfocar el TextBox para nueva entrada
            textBox1.Focus();
        }
    }
}